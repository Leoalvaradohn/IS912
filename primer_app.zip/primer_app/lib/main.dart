import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State createState() {
    return _MyAppState();
  }
}

class _MyAppState extends State<MyApp> {
  int contador = 10;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Hola mundo',
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.teal,
          title: const Text('Tarea 1.2'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'HECTOR LEONEL CHIRINOS:',
                style: TextStyle(
                  fontSize: 26,
                  color: Colors.teal[800],
                  fontWeight: FontWeight.w300,
                ),
              ),
              Text(
                'Valor del contador: $contador',
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.teal[600],
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
        floatingActionButton: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            FloatingActionButton(
              backgroundColor: Colors.amber[700],
              onPressed: () {
                setState(() {
                  contador += 2; // Suma 2 al contador
                });
              },
              child: const Icon(Icons.add),
            ),
            const SizedBox(height: 16),
            FloatingActionButton(
              backgroundColor: Colors.blue[700],
              onPressed: () {
                setState(() {
                  contador -= 2; // Resta 2 al contador
                });
              },
              child: const Icon(Icons.remove),
            ),
            const SizedBox(height: 16),
            FloatingActionButton(
              backgroundColor: Colors.green[700],
              onPressed: () {
                setState(() {
                  contador *= 2; // Multiplica el contador por 2
                });
              },
              child: const Icon(Icons.close),
            ),
            const SizedBox(height: 16),
            FloatingActionButton(
              backgroundColor: Colors.red[700],
              onPressed: () {
                setState(() {
                  contador ~/= 2; // Divide el contador entre 2
                });
              },
              child: const Icon(Icons.safety_divider_rounded),//No logre encontrar el icon.divide en su lugar itilice un icono diferente pero que hace la misma funcion.
            ),

          ],
        ),
      ),
    );
  }
}


